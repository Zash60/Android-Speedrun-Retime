package com.example.speedruneditor.java;

public enum ScreenState {
    INITIAL,
    EDITOR
}
